package com.company;

public class PrintWriter {
    public void println(String x) {
        // 模拟打印输出
        System.out.println(x);
    }
    
    public void close() {
        // 模拟关闭操作
    }
}