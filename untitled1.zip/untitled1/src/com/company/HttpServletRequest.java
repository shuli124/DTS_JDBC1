package com.company;

import javax.servlet.*;

public interface HttpServletRequest extends ServletRequest {
}