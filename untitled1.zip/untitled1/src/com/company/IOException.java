package com.company;

public class IOException extends Exception {
    public IOException(String message) {
        super(message);
    }
}