package com.company;

import javax.servlet.*;
import javax.servlet.http.*;

public class HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 默认实现
    }
}